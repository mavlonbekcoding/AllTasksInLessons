﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13DayCount
{
    public interface IDayService
    {
        int DayCount(int n);
    }
}
