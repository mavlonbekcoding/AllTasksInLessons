﻿using _13DayCount;

DayService dayService = new DayService();
Console.WriteLine(dayService.DayCount(2020));



